# yoRadio ST7789 284x76 – magyar, ESP32-S3

Ez egy külön, PlatformIO-s változat. Az eredeti három projektet nem módosítja.

## Kiindulópontok

- Funkciók, audió és VU: `yoRadio-ESP32-S3-N16R8_V-Tom_v0.8.8_NV3007_ST7789_76_mod_by_kc-dev`
- Kijelző- és kezelőszerv-kiosztás: a működő Arduino-IDE-s `yoradio_7789_76_ESP32S3`
- Magyar feliratok és ékezetek: a projektben már meglévő, a 170x320-as változattal egyező `utf8Hun.cpp`

## Aktív hardverbeállítás

| Funkció | GPIO |
| --- | ---: |
| TFT DC / CS / RST / háttérvilágítás | 9 / 10 / -1 / 18 |
| I2S DOUT / BCLK / LRC | 4 / 5 / 6 |
| Enkóder jobb / bal / nyomógomb | 40 / 41 / 39 |
| Infravevő | 38 |

Az aktív kijelző `DSP_ST7789_76`: a forrásban 284x76 képpont, fektetett tájolással.

## A kijelző elrendezése

- 24 órás óra és másodpercek a jobb oldalon;
- rövid magyar dátum (`ÉÉÉÉ.HH.NN.`) az óra feletti jobb felső sávban;
- a bal oldalon az Arduino-IDE-s projekt szűk, két soros címe;
- a VU-mérő kizárólag a kijelző alsó, 64–70. pixelsoraiban rajzol;
- az időjárássáv ezen a kis kijelzőn le van tiltva, hogy ne írjon a VU-ra.

A dátum csak a perc váltásakor frissül, és az óra PSRAM-os képkockájának kirajzolása után kerül a kijelzőre. A VU törlése csak a saját 7 pixeles területét érinti.

## Fordítás

Nyisd meg ezt a mappát Visual Studio Code-ban a PlatformIO bővítménnyel, majd építsd az `esp32-s3-devkitc1-n16r8` környezetet. A projekt saját `platformio.ini` fájlja már az ESP32-S3 N16R8 beállításait tartalmazza.

Az `Adafruit_ST7789.h`-t adó, SD nélküli Adafruit ST7735/ST7789-változat a projekt `lib` mappájában van. Ez szándékos: a PlatformIO-könyvtárnév korábban nem töltötte le megbízhatóan, így a projekt most önállóan tartalmazza a szükséges kijelzőkönyvtárat.

## Fordítási ellenőrzés

A projekt teljes PlatformIO-fordítása sikeresen lefutott az `esp32-s3-devkitc1-n16r8` környezettel. A kész `firmware.bin` a `.pio/build/esp32-s3-devkitc1-n16r8` mappában található.

- flash: 2 217 530 / 6 291 456 bájt (35,2%);
- RAM: 70 768 / 327 680 bájt (21,6%).

Ez fordítási ellenőrzés: a készülékre feltöltés, a kijelző valós megjelenése, a VU folyamatos működése, az enkóder és az infravevő még külön hardvertesztet igényel.

Firmware-feltöltés után külön, valódi kijelzőn ellenőrizd az orientációt, a VU két ágát, az enkóder forgásirányát és az infrát.
