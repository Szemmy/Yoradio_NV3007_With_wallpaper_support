"""Create the compact-display background manifest before PlatformIO builds SPIFFS."""

from pathlib import Path

Import("env")

options = (Path(env.subst("$PROJECT_DIR")) / "myoptions.h").read_text(encoding="utf-8")
if "#define DSP_MODEL DSP_NV3007_142" in options:
    IMAGE_BYTES = 428 * 142 * 2
    DEFAULT_IMAGE = "background_428x142.sr565"
    MANIFEST_NAME = "backgrounds142.txt"
else:
    IMAGE_BYTES = 284 * 76 * 2
    DEFAULT_IMAGE = "background_284x76.sr565"
    MANIFEST_NAME = "backgrounds76.txt"
ALLOWED = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-")

project_dir = Path(env.subst("$PROJECT_DIR"))
image_dir = project_dir / "data" / "data"
manifest = image_dir / MANIFEST_NAME

names = []
if image_dir.is_dir():
    for candidate in sorted(image_dir.glob("*.sr565"), key=lambda path: path.name.lower()):
        name = candidate.name
        if (
            name != DEFAULT_IMAGE
            and len(name) < 22
            and all(character in ALLOWED for character in name)
            and candidate.stat().st_size == IMAGE_BYTES
        ):
            names.append(name)

content = "\n".join(names) + ("\n" if names else "")
if not manifest.exists() or manifest.read_text(encoding="ascii") != content:
    manifest.write_text(content, encoding="ascii")
    print("Generated background manifest:", ", ".join(names) if names else "(no additional images)")
