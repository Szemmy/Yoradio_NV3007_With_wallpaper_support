param(
    [string]$OptionsFile = (Join-Path $PSScriptRoot "..\data\www\options.html.gz")
)

$sourceStream = [System.IO.File]::OpenRead($OptionsFile)
$gzipStream = [System.IO.Compression.GzipStream]::new($sourceStream, [System.IO.Compression.CompressionMode]::Decompress)
$reader = [System.IO.StreamReader]::new($gzipStream, [System.Text.Encoding]::UTF8)
$html = $reader.ReadToEnd()
$reader.Dispose()
$gzipStream.Dispose()
$sourceStream.Dispose()

$marker = '      <div class="flex-row group group_nokia hidden">'
$menu = @'
      <div class="flex-row group group_tft hidden">
        <a class="fb hl local" href="/background76.html">background / theme</a>
      </div>
'@

if (-not $html.Contains('href="/background76.html"')) {
    if (-not $html.Contains($marker)) { throw "The expected Screen-menu marker was not found in options.html.gz." }
    $html = $html.Replace($marker, $menu + $marker)
}

$temporary = "$OptionsFile.tmp"
$targetStream = [System.IO.File]::Open($temporary, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
$targetGzip = [System.IO.Compression.GzipStream]::new($targetStream, [System.IO.Compression.CompressionLevel]::Optimal)
$writer = [System.IO.StreamWriter]::new($targetGzip, [System.Text.Encoding]::UTF8)
$writer.Write($html)
$writer.Dispose()
$targetGzip.Dispose()
$targetStream.Dispose()

Move-Item -LiteralPath $temporary -Destination $OptionsFile -Force
Write-Output "Updated: $OptionsFile"
