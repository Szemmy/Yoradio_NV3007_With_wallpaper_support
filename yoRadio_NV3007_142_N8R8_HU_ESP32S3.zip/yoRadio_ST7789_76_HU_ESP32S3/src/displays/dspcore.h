#ifndef dspcore_h
#define dspcore_h
#pragma once

#if DSP_MODEL==DSP_DUMMY
  #define DUMMYDISPLAY
  #define DSP_NOT_FLIPPED

//#elif DSP_MODEL==DSP_ST7789       // https://k210.org/images/content/uploads/yoradio/ST7789.jpg
#elif DSP_MODEL==DSP_ST7789 || DSP_MODEL==DSP_ST7789_240 || DSP_MODEL==DSP_ST7789_170       // https://k210.org/images/content/uploads/yoradio/ST7789.jpg
  #define TIME_SIZE           52
  #define PSFBUFFER
  #include "displayST7789.h"

#elif DSP_MODEL==DSP_ST7789_76         // https://k210.org/images/content/uploads/yoradio/ST7789_76.mp4
  #define TIME_SIZE           35
  #define PSFBUFFER
  #include "displayST7789.h"

#elif DSP_MODEL==DSP_NV3007_142       /* NV3007 2.79' ~ kc-dev (09.06.26) */
  #define TIME_SIZE           35
  #define PSFBUFFER
  #include "displayST7789.h"

#elif DSP_MODEL==DSP_ILI9341
  #define TIME_SIZE           52
  #define PSFBUFFER
  #include "displayILI9341.h"

#elif DSP_MODEL==DSP_ST7796         // https://k210.org/images/content/uploads/yoradio/ST7796.jpg
  #define TIME_SIZE           70
  #define PSFBUFFER
  #include "displayST7796.h"

#elif DSP_MODEL==DSP_ILI9488 || DSP_MODEL==DSP_ILI9486  // https://k210.org/images/content/uploads/yoradio/ILI9488.jpg
  #define TIME_SIZE           70
  #define PSFBUFFER
  #include "displayILI9488.h"

#elif DSP_MODEL==DSP_SSD1322        
  #define TIME_SIZE           35
  #define DSP_OLED
  #include "displaySSD1322.h"

#endif

#endif
