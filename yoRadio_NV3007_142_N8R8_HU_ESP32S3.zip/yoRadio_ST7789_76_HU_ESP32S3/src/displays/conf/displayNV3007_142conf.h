/*************************************************************************************
    NV3007 428x142 landscape configuration.
    This is the enlarged version of the accepted ST7789_76 dashboard: the same
    information order, clock/date placement, two-channel VU meter and fonts.
*************************************************************************************/

#ifndef displayNV3007_142conf_h
#define displayNV3007_142conf_h

#define DSP_WIDTH       428
#define DSP_HEIGHT      142
#define TFT_FRAMEWDT    4
#define MAX_WIDTH       DSP_WIDTH-TFT_FRAMEWDT*2

#define BOOMBOX_STYLE

#define HIDE_HEAPBAR
//#define HIDE_VOLBAR
//#define HIDE_VOL
#define HIDE_VOLBAR_ONLY_MAIN_SCREEN
//#define HIDE_IP_ONLY_MAIN_SCREEN
#define HIDE_VOL_FOOTER
#define HIDE_WEATHER

#define bootLogoTop     26

constexpr uint16_t artistRowTop = 29;

/* SROLLS  */
// The station-name scroller ends five pixels before the date on the same top
// row: left=5, width=282 ends at x=286; the date begins at x=292.
const ScrollConfig metaConf       PROGMEM = {{ TFT_FRAMEWDT+1, TFT_FRAMEWDT+1, 3, WA_LEFT }, 180, true, 282, 5000, 3, 25 };
const ScrollConfig title1Conf     PROGMEM = {{ TFT_FRAMEWDT, artistRowTop, 2, WA_LEFT }, 170, true, 194, 5000, 3, 25 };
const ScrollConfig title2Conf     PROGMEM = {{ TFT_FRAMEWDT, 46, 2, WA_LEFT }, 170, true, 192, 5000, 3, 25 };
const ScrollConfig playlistConf   PROGMEM = {{ TFT_FRAMEWDT, 56, 2, WA_LEFT }, 180, true, MAX_WIDTH, 500, 3, 25 };
const ScrollConfig apTitleConf    PROGMEM = {{ TFT_FRAMEWDT+1, TFT_FRAMEWDT+1, 2, WA_CENTER }, 180, false, MAX_WIDTH-2, 0, 3, 25 };
const ScrollConfig apSettConf     PROGMEM = {{ TFT_FRAMEWDT, DSP_HEIGHT-13, 2, WA_LEFT }, 180, false, MAX_WIDTH, 0, 3, 25 };
const ScrollConfig weatherConf    PROGMEM = {{ TFT_FRAMEWDT+1, DSP_HEIGHT-22, 2, WA_CENTER }, 180, true, MAX_WIDTH-2, 0, 3, 30 };

/* BACKGROUNDS  */
const FillConfig   metaBGConf     PROGMEM = {{ 0, 0,  0, WA_LEFT }, DSP_WIDTH, 34, false };
const FillConfig   metaBGConfInv  PROGMEM = {{ 0, 36, 0, WA_LEFT }, DSP_WIDTH, 2,  false };
const FillConfig   volbarConf     PROGMEM = {{ TFT_FRAMEWDT, DSP_HEIGHT-13, 0, WA_CENTER }, MAX_WIDTH, 9, true };
const FillConfig  playlBGConf     PROGMEM = {{ 0, 49, 0, WA_LEFT }, DSP_WIDTH, 22, false };
const FillConfig  heapbarConf     PROGMEM = {{ 0, DSP_HEIGHT-24, 0, WA_LEFT }, DSP_WIDTH, 2, false };

/* WIDGETS  */
const WidgetConfig bootstrConf    PROGMEM = { 0, DSP_HEIGHT-19, 2, WA_CENTER };
const WidgetConfig bitrateConf    PROGMEM = { TFT_FRAMEWDT+32, DSP_HEIGHT-44, 2, WA_LEFT };

/* FOOTER */
const WidgetConfig iptxtConf      PROGMEM = { TFT_FRAMEWDT, 74, 2, WA_LEFT };
// Leave enough clearance for the large clock even when the hour starts with 2.
const WidgetConfig voltxtConf     PROGMEM = { TFT_FRAMEWDT+125, DSP_HEIGHT-44, 2, WA_LEFT };
// The channel number shares the upper-right information column: it is below
// the date and above the large clock. Right alignment keeps CH:100 and larger
// three-digit channel numbers entirely on-screen.
const WidgetConfig chtxtConf      PROGMEM = { TFT_FRAMEWDT, artistRowTop, 2, WA_RIGHT };
const WidgetConfig rssiConf       PROGMEM = { TFT_FRAMEWDT+2, DSP_HEIGHT-42, 2, WA_LEFT };

const WidgetConfig numConf        PROGMEM = { TFT_FRAMEWDT, DSP_HEIGHT-32, 0, WA_CENTER };
const WidgetConfig apNameConf     PROGMEM = { 0, 34, 2, WA_CENTER };
const WidgetConfig apName2Conf    PROGMEM = { 0, 49, 2, WA_CENTER };
const WidgetConfig apPassConf     PROGMEM = { 0, 69, 2, WA_CENTER };
const WidgetConfig apPass2Conf    PROGMEM = { 0, 84, 2, WA_CENTER };
// Seconds use the smaller 20x11 font at the right of this block.
const WidgetConfig clockConf      PROGMEM = { 22, DSP_HEIGHT-35, 0, WA_RIGHT };
const WidgetConfig bootWdtConf    PROGMEM = { 0, 162, 1, WA_CENTER };
const WidgetConfig vuConf         PROGMEM = { TFT_FRAMEWDT, DSP_HEIGHT-23, 1, WA_CENTER };
const WidgetConfig namedayConf    PROGMEM = { TFT_FRAMEWDT, 175, 2, WA_LEFT };
const WidgetConfig dateConf       PROGMEM = { TFT_FRAMEWDT, TFT_FRAMEWDT+1, 2, WA_RIGHT };

const ProgressConfig bootPrgConf  PROGMEM = { 136, 19, 8 };
const BitrateConfig fullbitrateConf PROGMEM = {{12, DSP_HEIGHT-39, 2, WA_LEFT}, 62 };

/* BANDS  */
const VUBandsConfig bandsConf     PROGMEM = { DSP_WIDTH/2-TFT_FRAMEWDT*2-3, 13, TFT_FRAMEWDT*2+6, 2, 17, 7 };

/* STRINGS  */
const char         numtxtFmt[]    PROGMEM = "%d";
const char           rssiFmt[]    PROGMEM = "WiFi %ddBm";
// Keep the icon and a full IPv4 address inside the left 192 pixels.
const char          iptxtFmt[]    PROGMEM = "\010%s";
const char         voltxtFmt[]    PROGMEM = "\023\025%d%%";
const char        bitrateFmt[]    PROGMEM = "%dKb";

/* MOVES  */
const MoveConfig    clockMove     PROGMEM = { 0, 176, -1 };
const MoveConfig   weatherMove    PROGMEM = { 0, 0, -1 };
const MoveConfig   weatherMoveVU  PROGMEM = { 0, 0, -1 };

#endif
// clang-format on
