/*************************************************************************************
    ST7789 284x76 displays configuration file.
    Copy this file to yoRadio/src/displays/conf/displayST7789conf_custom.h
    and modify it
    More info on https://github.com/e2002/yoradio/wiki/Widgets#widgets-description
*************************************************************************************/

#ifndef displayST778976conf_h
#define displayST778976conf_h

#define DSP_WIDTH       284
#define DSP_HEIGHT      76
#define TFT_FRAMEWDT    2
#define MAX_WIDTH       DSP_WIDTH-TFT_FRAMEWDT*2

#define BOOMBOX_STYLE

#define HIDE_HEAPBAR
//#define HIDE_VOLBAR
//#define HIDE_VOL
#define HIDE_VOLBAR_ONLY_MAIN_SCREEN // Ukrywa pasek glosnosci tylko na glownym ekranie
//#define HIDE_IP_ONLY_MAIN_SCREEN// Ukrywa adres IP tylko na glownym ekranie
#define HIDE_VOL_FOOTER // Ukrywa stopke na ekranie glosnosci
// Az idő/dátum és a VU számára a keskeny kijelzőn nincs külön időjárássáv.
#define HIDE_WEATHER

#define bootLogoTop     14

/* SROLLS  */                            /* {{ left, top, fontsize, align }, buffsize, uppercase, width, scrolldelay, scrolldelta, scrolltime } */
// Az Arduino-IDE-s 76-os változat bevált, bal oldali szövegelrendezése.
// A jobb oldali felső sáv szabadon marad a dátumnak és az órának.
const ScrollConfig metaConf       PROGMEM = {{ TFT_FRAMEWDT+1, TFT_FRAMEWDT+1, 2, WA_LEFT }, 140, true, 200, 5000, 2, 25 };
const ScrollConfig title1Conf     PROGMEM = {{ TFT_FRAMEWDT, 21, 1, WA_LEFT }, 135, true, DSP_WIDTH/2-20, 5000, 2, 25 };
const ScrollConfig title2Conf     PROGMEM = {{ TFT_FRAMEWDT, 30, 1, WA_LEFT }, 135, true, DSP_WIDTH/2-20, 5000, 2, 25 };
const ScrollConfig playlistConf   PROGMEM = {{ TFT_FRAMEWDT, 30, 1, WA_LEFT }, 140, true, MAX_WIDTH, 500, 2, 25 };
const ScrollConfig apTitleConf    PROGMEM = {{ TFT_FRAMEWDT+1, TFT_FRAMEWDT+1, 1, WA_CENTER }, 140, false, MAX_WIDTH-2, 0, 2, 25 };
const ScrollConfig apSettConf     PROGMEM = {{ TFT_FRAMEWDT, 64-7, 1, WA_LEFT }, 140, false, MAX_WIDTH, 0, 2, 25 };
const ScrollConfig weatherConf    PROGMEM = {{ TFT_FRAMEWDT+1, DSP_HEIGHT-12, 1, WA_CENTER }, 140, true, MAX_WIDTH-2, 0, 2, 30 };
//const ScrollConfig weatherConf    PROGMEM = {{ TFT_FRAMEWDT, 95, 1, WA_CENTER }, 140, false, MAX_WIDTH, 0, 2, 30 };

/* BACKGROUNDS  */                       /* {{ left, top, fontsize, align }, width, height, outlined } */
const FillConfig   metaBGConf     PROGMEM = {{ 0, 0,  0, WA_LEFT }, DSP_WIDTH, 18, false };
const FillConfig   metaBGConfInv  PROGMEM = {{ 0, 19, 0, WA_LEFT }, DSP_WIDTH, 1,  false };
//const FillConfig   volbarConf     PROGMEM = {{ TFT_FRAMEWDT, 240-TFT_FRAMEWDT-6, 0, WA_LEFT }, MAX_WIDTH, 4, true };
//const FillConfig   volbarConf     PROGMEM = {{ DSP_WIDTH/2, DSP_HEIGHT-0, 0, WA_LEFT }, DSP_WIDTH/2-TFT_FRAMEWDT*2, 3, true };
const FillConfig   volbarConf     PROGMEM = {{ TFT_FRAMEWDT, DSP_HEIGHT-7, 0, WA_CENTER }, MAX_WIDTH, 5, true };
const FillConfig  playlBGConf     PROGMEM = {{ 0, 26, 0, WA_LEFT }, DSP_WIDTH, 12, false };
const FillConfig  heapbarConf     PROGMEM = {{ 0, 63, 0, WA_LEFT }, DSP_WIDTH, 1, false };

/* WIDGETS  */                           /* { left, top, fontsize, align } */
const WidgetConfig bootstrConf    PROGMEM = { 0, DSP_HEIGHT-10, 1, WA_CENTER };
const WidgetConfig bitrateConf    PROGMEM = { TFT_FRAMEWDT+21, 63-10-10, 1, WA_LEFT };

/* FOOTER */
const WidgetConfig iptxtConf     PROGMEM = { TFT_FRAMEWDT, 64-11, 1, WA_LEFT };
// A CH és a hangerő egy 5x7-es karakterrel balrább kerül: két számjegyű
// hangerőnél sem érnek bele az óra területébe.
const WidgetConfig voltxtConf     PROGMEM = { TFT_FRAMEWDT+104, 63-10-10, 1, WA_LEFT };  // Hangerő
const WidgetConfig chtxtConf      PROGMEM = { TFT_FRAMEWDT+64, 63-10-10, 1, WA_LEFT }; //→ aktualny kanał CH:text (stopka PLAYER)
const WidgetConfig rssiConf       PROGMEM = { TFT_FRAMEWDT+1, 63-10-10, 1, WA_LEFT };

const WidgetConfig numConf        PROGMEM = { TFT_FRAMEWDT, 59, 0, WA_CENTER };
const WidgetConfig apNameConf     PROGMEM = { 0, 18, 1, WA_CENTER };
const WidgetConfig apName2Conf    PROGMEM = { 0, 26, 1, WA_CENTER };
const WidgetConfig apPassConf     PROGMEM = { 0, 37, 1, WA_CENTER };
const WidgetConfig apPass2Conf    PROGMEM = { 0, 45, 1, WA_CENTER };
const WidgetConfig clockConf      PROGMEM = { 0, 57, 0, WA_RIGHT };
const WidgetConfig bootWdtConf    PROGMEM = { 0, 162, 1, WA_CENTER };
const WidgetConfig vuConf         PROGMEM = { 2, DSP_HEIGHT-12, 1, WA_CENTER };
const WidgetConfig namedayConf    PROGMEM = { TFT_FRAMEWDT, 175, 2, WA_LEFT }; // Zmieniony nowy wiersz „imieniny”
// Rövid, magyar numerikus dátum a felső sáv jobb oldalán. Nem érinti a VU-területet.
const WidgetConfig dateConf       PROGMEM = { TFT_FRAMEWDT, 9, 1, WA_RIGHT };

const ProgressConfig bootPrgConf  PROGMEM = { 90, 10, 4 };
const BitrateConfig fullbitrateConf PROGMEM = {{8, 64-10-10, 1, WA_LEFT}, 41 }; // left, top, fontsize, align, border size

/* BANDS  */                             /* { onebandwidth,               onebandheight, bandsHspace, bandsVspace, numofbands, fadespeed } */
// A 4 px/refresh esés élőbb mozgást ad, miközben az Audio.cpp rövid idejű
// kisimítása megakadályozza, hogy a zene minden mintacsúcsa teljes kitérést adjon.
const VUBandsConfig bandsConf     PROGMEM = { DSP_WIDTH/2-TFT_FRAMEWDT*2-2, 7,             TFT_FRAMEWDT*2+4, 1, 17, 4 };

/* STRINGS  */
const char         numtxtFmt[]    PROGMEM = "%d";
const char           rssiFmt[]    PROGMEM = "WiFi %ddBm";
const char          iptxtFmt[]    PROGMEM = "\010 %s";
const char         voltxtFmt[]    PROGMEM = "\023\025%d%%";
// Egybeírt mértékegység: például „128Kb”, egy teljes karakterhellyel rövidebb.
const char        bitrateFmt[]    PROGMEM = "%dKb";

/* MOVES  */                             /* { left, top, width } */
const MoveConfig    clockMove     PROGMEM = { 0, 176, -1 };
const MoveConfig   weatherMove    PROGMEM = { 0, 0, -1 };
const MoveConfig   weatherMoveVU  PROGMEM = { 0, 0, -1 };

#endif
// clang-format on
