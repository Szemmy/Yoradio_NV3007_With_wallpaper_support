#ifndef background76_h
#define background76_h

#include <stddef.h>
#include <stdint.h>

class DspCore;

// The compact ST7789_76 and landscape NV3007_142 dashboards use an optional
// image stored in SPIFFS.
// All functions deliberately fall back to false when the image is absent, so
// the normal YoRadio theme remains fully functional without extra files.
namespace Background76 {

constexpr size_t kFilenameLength = 22;
#if DSP_MODEL == DSP_NV3007_142
constexpr size_t kImageBytes = 428U * 142U * sizeof(uint16_t);
#else
constexpr size_t kImageBytes = 284U * 76U * sizeof(uint16_t);
#endif

bool available();
bool draw(DspCore& display);
bool restore(DspCore& display, int16_t x, int16_t y, int16_t width, int16_t height);
bool copyTo(uint16_t* destination, int16_t x, int16_t y, int16_t width, int16_t height);

// The Web UI uses names only, never arbitrary paths.  "default" refers to
// the image supplied for the active display profile. Every valid .sr565
// image packaged in data/ is selectable too; images uploaded through the Web
// UI live under /bg76/.  Each name receives its own compact colour profile.
bool validFilename(const char* filename);
bool isDefaultFilename(const char* filename);
bool makeImagePath(const char* filename, char* destination, size_t destinationSize);
bool makeUploadedImagePath(const char* filename, char* destination, size_t destinationSize);
bool makeProfilePath(const char* filename, char* destination, size_t destinationSize);
bool imageExists(const char* filename);
bool isUploadedImage(const char* filename);
bool removeImage(const char* filename);
void reload();

// These fifteen colours cover all transparent items visible on the compact
// ST7789 dashboard.  Opaque panel/background colours deliberately remain
// controlled by mytheme.h, as they are not drawn over the photo.
constexpr size_t kThemeColorCount = 15;
void getThemeColors(const char* filename, uint16_t* colors, size_t count);
bool saveThemeColors(const char* filename, const uint16_t* colors, size_t count);
void applySelectedTheme();

}  // namespace Background76

#endif
