# NV3007 428x142 háttérkép

Az NV3007-es, fekvő YoRadio-kijelző opcionálisan innen tölti be a hátteret:

```
/data/background_428x142.sr565
```

A PlatformIO-projektben ennek a helyi fájlneve:

```
data/data/background_428x142.sr565
```

## Pontos formátum

- **428 × 142 pixel**, fekvő tájolás
- **RGB565 / SR565**, 16 bit/pixel
- **121 552 bájt** pontosan (`428 × 142 × 2`)
- Az SR565 a Moon Radio formátuma: a 16 bites RGB565 szín **magas bájtja van előbb**.

PNG vagy JPG fájlt közvetlenül nem olvas. A rádió WebUI-jának Háttérkép / téma
lapja az ilyen képeket automatikusan a megfelelő méretű SR565 fájllá alakítja.

## Használat

1. A fenti pontos nevű és méretű fájlt tedd a `data/data` mappába, vagy töltsd
   fel a WebUI-n keresztül.
2. A PlatformIO-ban futtasd az **Upload Filesystem Image** műveletet, ha a
   fájlt a projektmappába tetted.
3. A WebUI-n válaszd ki, engedélyezd és alkalmazd a hátteret. Az alkalmazás
   egyszer újraindítja a rádiót, hogy minden widget a kiválasztott
   színprofillal induljon.

Sikeres betöltéskor a soros naplóban ehhez hasonló sor jelenik meg:

```
[BG76] Loaded /data/background_428x142.sr565 at 100% into PSRAM (121552 bytes)
```

Ha a fájl hiányzik vagy nem pontosan 121 552 bájt, a program automatikusan az
egyszínű YoRadio-hátteret használja. A háttérkép ezért opcionális; a rádió és
az audió működése változatlan.

## Mit őriz meg a réteg?

A VU-mérő, a futó állomás-/cím-szövegek, az óra másodpercmezője, a villogó
kettőspont és a magyar dátum nem egyszínű téglalappal törlődik. Minden
frissítés előtt a képnek csak az érintett kis részlete kerül vissza a
PSRAM-ból a kijelzőre, majd erre rajzolódik az új adat.
