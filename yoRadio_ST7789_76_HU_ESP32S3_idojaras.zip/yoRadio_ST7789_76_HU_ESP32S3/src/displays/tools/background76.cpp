#include "../../core/options.h"
#include "background76.h"

#if DSP_MODEL == DSP_ST7789_76 || DSP_MODEL == DSP_NV3007_142

#include <Arduino.h>
#include <SPIFFS.h>

#include "../../core/config.h"
#include "../dspcore.h"

namespace Background76 {
namespace {

#if DSP_MODEL == DSP_NV3007_142
constexpr int16_t kWidth = 428;
constexpr int16_t kHeight = 142;
constexpr const char* kDefaultImagePath = "/data/background_428x142.sr565";
#else
constexpr int16_t kWidth = 284;
constexpr int16_t kHeight = 76;
constexpr const char* kDefaultImagePath = "/data/background_284x76.sr565";
#endif
constexpr size_t kPixelCount = static_cast<size_t>(kWidth) * kHeight;
constexpr const char* kDefaultName = "default";
constexpr const char* kImagePrefix = "/bg76/";
constexpr const char* kDataImagePrefix = "/data/";
constexpr uint32_t kLegacyProfileMagic = 0x42373654UL;
constexpr uint32_t kProfileMagic = 0x42373655UL;
constexpr uint32_t kRetryIntervalMs = 5000;

enum ThemeColorIndex : uint8_t {
    TC_META,
    TC_TITLE1,
    TC_TITLE2,
    TC_CLOCK,
    TC_SECONDS,
    TC_DATE,
    TC_BITRATE,
    TC_RSSI,
    TC_CH,
    TC_VOL,
    TC_IP,
    TC_VUMIN,
    TC_VUMID,
    TC_VUMAX,
    TC_DIGIT,
};

struct ThemeProfile {
    uint32_t magic;
    uint16_t colors[kThemeColorCount];
};
static_assert(sizeof(ThemeProfile) == 36, "Unexpected background theme profile size");

uint16_t* gPixels = nullptr;
uint32_t gLastAttempt = 0;
uint8_t gLoadedIntensity = 255;
char gLoadedFilename[kFilenameLength] = {};

bool isInsideImage(int16_t x, int16_t y, int16_t width, int16_t height) {
    return width > 0 && height > 0 && x >= 0 && y >= 0 && x + width <= kWidth && y + height <= kHeight;
}

bool makePath(const char* prefix, const char* filename, char* destination, size_t destinationSize) {
    if (prefix == nullptr || filename == nullptr || destination == nullptr || destinationSize == 0) { return false; }
    const int written = snprintf(destination, destinationSize, "%s%s", prefix, filename);
    return written > 0 && static_cast<size_t>(written) < destinationSize;
}

bool isImageAtPath(const char* path) {
    File file = SPIFFS.open(path, FILE_READ);
    const bool valid = file && file.size() == kImageBytes;
    if (file) { file.close(); }
    return valid;
}

void setThemeColors(const uint16_t* colors) {
    config.theme.meta = colors[TC_META];
    config.theme.title1 = colors[TC_TITLE1];
    config.theme.title2 = colors[TC_TITLE2];
    config.theme.clock = colors[TC_CLOCK];
    config.theme.seconds = colors[TC_SECONDS];
    config.theme.date = colors[TC_DATE];
    config.theme.bitrate = colors[TC_BITRATE];
    config.theme.rssi = colors[TC_RSSI];
    config.theme.ch = colors[TC_CH];
    config.theme.vol = colors[TC_VOL];
    config.theme.ip = colors[TC_IP];
    config.theme.vumin = colors[TC_VUMIN];
    config.theme.vumid = colors[TC_VUMID];
    config.theme.vumax = colors[TC_VUMAX];
    config.theme.digit = colors[TC_DIGIT];
    config.theme.weather = colors[kWeatherColorIndex];
}

void readThemeColors(uint16_t* colors) {
    colors[TC_META] = config.theme.meta;
    colors[TC_TITLE1] = config.theme.title1;
    colors[TC_TITLE2] = config.theme.title2;
    colors[TC_CLOCK] = config.theme.clock;
    colors[TC_SECONDS] = config.theme.seconds;
    colors[TC_DATE] = config.theme.date;
    colors[TC_BITRATE] = config.theme.bitrate;
    colors[TC_RSSI] = config.theme.rssi;
    colors[TC_CH] = config.theme.ch;
    colors[TC_VOL] = config.theme.vol;
    colors[TC_IP] = config.theme.ip;
    colors[TC_VUMIN] = config.theme.vumin;
    colors[TC_VUMID] = config.theme.vumid;
    colors[TC_VUMAX] = config.theme.vumax;
    colors[TC_DIGIT] = config.theme.digit;
    colors[kWeatherColorIndex] = config.theme.weather;
}

bool readProfile(const char* filename, ThemeProfile& profile, uint16_t defaultWeather) {
    char path[32];
    if (!makeProfilePath(filename, path, sizeof(path))) { return false; }
    File file = SPIFFS.open(path, FILE_READ);
    if (!file || file.size() != sizeof(profile)) {
        if (file) { file.close(); }
        return false;
    }
    const size_t read = file.read(reinterpret_cast<uint8_t*>(&profile), sizeof(profile));
    file.close();
    if (read != sizeof(profile)) { return false; }
    if (profile.magic == kLegacyProfileMagic) {
        // The old 36-byte profile used the final two bytes as padding.
        profile.colors[kWeatherColorIndex] = defaultWeather;
        return true;
    }
    return profile.magic == kProfileMagic;
}

uint16_t dimPixel(uint16_t pixel, uint8_t intensity) {
    if (intensity >= 100) { return pixel; }
    const uint16_t red = static_cast<uint16_t>(((pixel >> 11U) & 0x1FU) * intensity / 100U);
    const uint16_t green = static_cast<uint16_t>(((pixel >> 5U) & 0x3FU) * intensity / 100U);
    const uint16_t blue = static_cast<uint16_t>((pixel & 0x1FU) * intensity / 100U);
    return static_cast<uint16_t>((red << 11U) | (green << 5U) | blue);
}

bool loadImage() {
    const char* const filename = config.store.bg76File[0] == '\0' ? kDefaultName : config.store.bg76File;
    const uint8_t intensity = constrain(config.store.bg76Intensity, 0, 100);
    if (gPixels != nullptr && strcmp(gLoadedFilename, filename) == 0 && gLoadedIntensity == intensity) { return true; }
    reload();

    const uint32_t now = millis();
    if (gLastAttempt != 0 && now - gLastAttempt < kRetryIntervalMs) { return false; }
    gLastAttempt = now;

    char path[32];
    if (!makeImagePath(filename, path, sizeof(path))) { return false; }
    File file = SPIFFS.open(path, FILE_READ);
    if (!file || file.size() != kImageBytes) {
        if (file) { file.close(); }
        return false;
    }

    uint16_t* const pixels = static_cast<uint16_t*>(ps_malloc(kImageBytes));
    if (pixels == nullptr) {
        Serial.printf("[BG76] PSRAM allocation failed (%u bytes)\n", static_cast<unsigned>(kImageBytes));
        file.close();
        return false;
    }

    const size_t bytesRead = file.read(reinterpret_cast<uint8_t*>(pixels), kImageBytes);
    file.close();
    if (bytesRead != kImageBytes) {
        free(pixels);
        Serial.printf("[BG76] Background read error: %u/%u bytes\n", static_cast<unsigned>(bytesRead), static_cast<unsigned>(kImageBytes));
        return false;
    }

    // SR565 stores RGB565 words most-significant byte first.  The ESP32
    // framebuffer uses native uint16_t values, so swap every loaded word once.
    for (size_t i = 0; i < kPixelCount; ++i) {
        const uint16_t stored = pixels[i];
        pixels[i] = dimPixel(static_cast<uint16_t>((stored << 8U) | (stored >> 8U)), intensity);
    }

    gPixels = pixels;
    gLoadedIntensity = intensity;
    strlcpy(gLoadedFilename, filename, sizeof(gLoadedFilename));
    Serial.printf("[BG76] Loaded %s at %u%% into PSRAM (%u bytes)\n", path, intensity, static_cast<unsigned>(kImageBytes));
    return true;
}

}  // namespace

bool isDefaultFilename(const char* filename) {
    return filename != nullptr && strcmp(filename, kDefaultName) == 0;
}

bool validFilename(const char* filename) {
    if (filename == nullptr || filename[0] == '\0') { return false; }
    if (isDefaultFilename(filename)) { return true; }
    const size_t length = strlen(filename);
    if (length < 7 || length >= kFilenameLength || !String(filename).endsWith(".sr565")) { return false; }
    for (size_t i = 0; i < length; ++i) {
        const char c = filename[i];
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '.')) {
            return false;
        }
    }
    return true;
}

bool makeImagePath(const char* filename, char* destination, size_t destinationSize) {
    if (destination == nullptr || destinationSize == 0 || !validFilename(filename)) { return false; }
    if (isDefaultFilename(filename)) {
        const int written = snprintf(destination, destinationSize, "%s", kDefaultImagePath);
        return written > 0 && static_cast<size_t>(written) < destinationSize;
    }

    // SPIFFS is flat internally.  Prefer a same-named Web-UI upload, then
    // fall back to an image packaged in data/.  This makes data/data/*.sr565
    // files selectable after an Upload Filesystem Image without a special name.
    char uploadedPath[32] = {};
    if (makePath(kImagePrefix, filename, uploadedPath, sizeof(uploadedPath)) && isImageAtPath(uploadedPath)) {
        strlcpy(destination, uploadedPath, destinationSize);
        return true;
    }
    return makePath(kDataImagePrefix, filename, destination, destinationSize);
}

bool makeUploadedImagePath(const char* filename, char* destination, size_t destinationSize) {
    return validFilename(filename) && !isDefaultFilename(filename) && makePath(kImagePrefix, filename, destination, destinationSize);
}

bool makeProfilePath(const char* filename, char* destination, size_t destinationSize) {
    if (destination == nullptr || destinationSize == 0 || !validFilename(filename)) { return false; }
    const int written = isDefaultFilename(filename)
        ? snprintf(destination, destinationSize, "/bg76/default.t")
        : snprintf(destination, destinationSize, "%s%s.t", kImagePrefix, filename);
    return written > 0 && static_cast<size_t>(written) < destinationSize;
}

bool imageExists(const char* filename) {
    char path[32];
    if (!makeImagePath(filename, path, sizeof(path))) { return false; }
    return isImageAtPath(path);
}

bool isUploadedImage(const char* filename) {
    char path[32] = {};
    return makeUploadedImagePath(filename, path, sizeof(path)) && isImageAtPath(path);
}

bool removeImage(const char* filename) {
    if (isDefaultFilename(filename) || !isUploadedImage(filename)) { return false; }
    char imagePath[32];
    char profilePath[32];
    if (!makeUploadedImagePath(filename, imagePath, sizeof(imagePath)) || !makeProfilePath(filename, profilePath, sizeof(profilePath))) { return false; }
    const bool removed = SPIFFS.remove(imagePath);
    SPIFFS.remove(profilePath);
    if (strcmp(config.store.bg76File, filename) == 0) {
        config.saveValue(config.store.bg76File, kDefaultName, sizeof(config.store.bg76File), false);
        config.saveValue(&config.store.bg76Enabled, false, true, true);
        reload();
    }
    return removed;
}

void reload() {
    if (gPixels != nullptr) {
        free(gPixels);
        gPixels = nullptr;
    }
    gLoadedFilename[0] = '\0';
    gLoadedIntensity = 255;
    gLastAttempt = 0;
}

bool available() {
    return config.store.bg76Enabled && loadImage();
}

bool copyTo(uint16_t* destination, int16_t x, int16_t y, int16_t width, int16_t height) {
    if (destination == nullptr || !isInsideImage(x, y, width, height) || !available()) { return false; }

    for (int16_t row = 0; row < height; ++row) {
        memcpy(destination + static_cast<size_t>(row) * width,
               gPixels + static_cast<size_t>(y + row) * kWidth + x,
               static_cast<size_t>(width) * sizeof(uint16_t));
    }
    return true;
}

bool restore(DspCore& display, int16_t x, int16_t y, int16_t width, int16_t height) {
    if (!isInsideImage(x, y, width, height) || !available()) { return false; }

    display.startWrite();
    display.setAddrWindow(x, y, width, height);
    for (int16_t row = 0; row < height; ++row) {
        const uint16_t* const source = gPixels + static_cast<size_t>(y + row) * kWidth + x;
        display.writePixels(const_cast<uint16_t*>(source), width);
    }
    display.endWrite();
    return true;
}

bool draw(DspCore& display) {
    return restore(display, 0, 0, kWidth, kHeight);
}

void getThemeColors(const char* filename, uint16_t* colors, size_t count) {
    if (colors == nullptr || count < kThemeColorCount) { return; }
    theme_t currentTheme = config.theme;
    config.loadTheme();
    readThemeColors(colors);
    ThemeProfile profile{};
    if (validFilename(filename) && readProfile(filename, profile, colors[kWeatherColorIndex])) {
        memcpy(colors, profile.colors, sizeof(profile.colors));
    }
    config.theme = currentTheme;
}

bool saveThemeColors(const char* filename, const uint16_t* colors, size_t count) {
    if (!validFilename(filename) || colors == nullptr || count < kThemeColorCount) { return false; }
    char path[32];
    if (!makeProfilePath(filename, path, sizeof(path))) { return false; }
    ThemeProfile profile{};
    profile.magic = kProfileMagic;
    memcpy(profile.colors, colors, sizeof(profile.colors));
    File file = SPIFFS.open(path, FILE_WRITE);
    if (!file) { return false; }
    const size_t written = file.write(reinterpret_cast<const uint8_t*>(&profile), sizeof(profile));
    file.close();
    return written == sizeof(profile);
}

void applySelectedTheme() {
    const char* const filename = config.store.bg76File[0] == '\0' ? kDefaultName : config.store.bg76File;
    ThemeProfile profile{};
    if (validFilename(filename) && readProfile(filename, profile, config.theme.weather)) { setThemeColors(profile.colors); }
}

}  // namespace Background76

#else

namespace Background76 {
bool available() { return false; }
bool draw(DspCore&) { return false; }
bool restore(DspCore&, int16_t, int16_t, int16_t, int16_t) { return false; }
bool copyTo(uint16_t*, int16_t, int16_t, int16_t, int16_t) { return false; }
bool validFilename(const char*) { return false; }
bool isDefaultFilename(const char*) { return false; }
bool makeImagePath(const char*, char*, size_t) { return false; }
bool makeUploadedImagePath(const char*, char*, size_t) { return false; }
bool makeProfilePath(const char*, char*, size_t) { return false; }
bool imageExists(const char*) { return false; }
bool isUploadedImage(const char*) { return false; }
bool removeImage(const char*) { return false; }
void reload() {}
void getThemeColors(const char*, uint16_t*, size_t) {}
bool saveThemeColors(const char*, const uint16_t*, size_t) { return false; }
void applySelectedTheme() {}
}  // namespace Background76

#endif
